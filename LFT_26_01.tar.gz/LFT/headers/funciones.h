

void *crea_imagen( int ray, int numan);

//~ FILE *apertura_archivo2(int contador, int contador2, int contador3);
