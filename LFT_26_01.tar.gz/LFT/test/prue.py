import /home/pablo/Resultados_C/LFT/headers/head.py


print "Holañ"
